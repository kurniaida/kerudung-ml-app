
import streamlit as st
import cv2
import numpy as np
import os
from PIL import Image

from sklearn.neighbors import KNeighborsClassifier

def extract_avg_rgb(image):
    img = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    avg_color = img.mean(axis=0).mean(axis=0)
    return avg_color

# Load dataset citra
X = []
y = []
for fname in os.listdir("skin_samples"):
    path = os.path.join("skin_samples", fname)
    label = fname.split("_")[0]
    img = cv2.imread(path)
    feat = extract_avg_rgb(img)
    X.append(feat)
    y.append(label)

# Train model
model = KNeighborsClassifier(n_neighbors=1)
model.fit(X, y)

st.title("Rekomendasi Warna Kerudung Berbasis Citra Warna Kulit + ML")

uploaded_file = st.file_uploader("Upload foto warna kulit (misal: foto tangan)", type=["jpg", "png", "jpeg"])

if uploaded_file is not None:
    img = Image.open(uploaded_file)
    st.image(img, caption="Citra yang diupload", width=200)
    img_array = np.array(img)
    if len(img_array.shape) == 3:
        if img_array.shape[2] == 4:
            img_array = cv2.cvtColor(img_array, cv2.COLOR_RGBA2BGR)
        else:
            img_array = cv2.cvtColor(img_array, cv2.COLOR_RGB2BGR)
        feat = extract_avg_rgb(img_array).reshape(1, -1)
        pred = model.predict(feat)[0]
        st.success(f"Prediksi warna kulit: {pred.replace('_', ' ').title()}")

        rekom = {
            "putih": ["merah_muda", "lavender", "peach"],
            "kuning_langsat": ["biru_muda", "hijau_mint", "coral"],
            "sawo_matang": ["burgundy", "mustard", "olive"],
            "gelap": ["ungu_tua", "maroon", "emerald"]
        }
        st.subheader("Rekomendasi Kerudung:")
        for warna in rekom.get(pred, []):
            st.markdown(f"- {warna.replace('_', ' ').title()}")
            try:
                img_ker = Image.open(f"kerudung_images/{warna}.jpg")
                st.image(img_ker, caption=f"Warna {warna.replace('_', ' ').title()}", width=150)
            except:
                st.info(f"[Gambar warna {warna} belum tersedia]")
